<!-- jouw HTML voor een Footer komt hier... 
Benoem hier ten minste je naam en de tijd
-->

<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="css/style.css?v=<?php echo time(); ?>">
</head>

<body>

    <div class="sticky-footer">
        <div class="footer">
            <div class="copyright">
                <p>Copyright &copy;2023 21/06 Kevin Xiu</p>
            </div>
        </div>
    </div>

</body>

</html>