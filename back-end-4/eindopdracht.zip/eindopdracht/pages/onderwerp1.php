<!-- jouw HTML met de inhoud over onderwerp 1 komt hier... -->

<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="css/style.css?v=<?php echo time(); ?>">
</head>
<body>
    
    <div class="wrapper">
        <img src="images/minecraft.png" class="minecraft">
        <div class="text">
            <h1>Minecraft</h1>
            <p>Minecraft is echt een geweldige game, man! Het is een sandbox-spel waarin je je eigen wereld kunt bouwen en verkennen. Ik bedoel, hoe cool is dat? Het spel is ontwikkeld door Mojang Studios en sinds de release in 2011 is het mega populair geworden.</p>
        
            <p>In Minecraft begin je met helemaal niets, alleen een oneindig landschap vol met blokken. Je kunt die blokken verzamelen en gebruiken om van alles te bouwen. Van simpele hutjes tot gigantische kastelen, de mogelijkheden zijn eindeloos. Er zijn verschillende game modes, maar mijn favoriet is survival.</p>
        
            <p>In de survival mode moet je echt je best doen om te overleven. Je moet vechten tegen enge monsters die 's nachts tevoorschijn komen en je moet grondstoffen verzamelen om te kunnen bouwen en overleven. Het geeft echt een kick als je erin slaagt om een veilig onderkomen te bouwen en de vijanden op afstand te houden. Maar het is ook een constante uitdaging, want je moet altijd alert zijn en zorgen dat je genoeg voedsel en middelen hebt.</p>
        
            <p>Wat ik ook geweldig vind aan survival is dat je echt een gevoel van voldoening krijgt als je vooruitgang boekt. Het is zo bevredigend om vanuit het niets een bloeiende boerderij te creëren en een uitgebreid netwerk van tunnels en mijnen aan te leggen. Het voelt als een echt avontuur, waarin je steeds nieuwe dingen ontdekt en jezelf blijft uitdagen. </p>
        
            <p>Dus als je op zoek bent naar een spannende en uitdagende spelervaring, raad ik je zeker aan om survival-modus in Minecraft te proberen. Het zal je zeker meeslepen in een wereld vol avontuur en overleving.</p>
        </div>
    </div>

</body>
</html>