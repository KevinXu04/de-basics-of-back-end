<!-- jouw HTML voor een Footer komt hier... 
Benoem hier ten minste je naam en de tijd
-->

<div class="sticky-footer">
    <div class="footer">
        <div class="copyright">
            <p>Copyright &copy;2023 21/06 Kevin Xiu</p>
        </div>
    </div>
</div>
